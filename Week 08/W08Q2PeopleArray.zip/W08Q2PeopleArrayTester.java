/*
 Author: Mike O'Malley
 Source: PersonTester.java
Descrtn: Code to answer Question Two (below).

Ammendment History
Ver   Date        Author    Details
----- ----------- --------  ---------------------------------------------------
0.001 09-Sep-2022 Mike O    Created.

*/

/*
Question Two

You are to create an application with a Person class and a separate class (with the main() method). The Person class is to have 3 private instance variables: an id (int), age in years (int) and height in cms(int). The Person class must also have an appropriate constructor to assign initial values to the three instance variables as well as a getter and setter for each instance variable.

You will also be required to include a toString() method in the Person class. The toString() method is to return a String representation of a person�s id, age and height. You are provided with the code for the toString() method below. If a toString() method is included in a class, then it will be called implicitly wherever a string representation of an object of the class is required (for example, in a print statement)> Note that the toString() method will override the toString() method that is inherited by all classes from the Object class. You will learn more about inheritance and overriding methods in the next unit.

The class diagram for the Person class is shown in question 1 above.

The main( ) method, is to create an array of Person objects from data provided in three arrays. One array is to contain the person ids, one is to contain their ages and one is to contains their heights. For example, the data for 7 people could be provided as follows:

        int n = 7;
        int[] ids  =    { 1,   2,   3,   4,   5,   6,   7   };
        int[] ages =    { 23,  24,  22,  23,  24,  22,  23  };
        int[] heights = { 180, 182, 180, 178, 177, 178, 178 };

The data above means that the first person has an id of 1, an age of 23 years and a height of 180cms etc.

The application is to:

�	display the array of Person objects.
�	use a sort method (that you will write) to sort the array of Person objects
�	display the sorted array

The sort method is to use the insertion sort algorithm. It is to sort the Persons array of objects in decreasing order of age. The algorithm for insertion sort is discussed in the lecture and the code to use the insertion sort algorithm to sort a list integers is also provided in the lecture slides. The code in the lecture slides will have to be modified to sort a list of Person objects based on their ages.


Sample output for the completed application (to be completed in Part B) is shown below (and continued on the next page)

Contents of the array:
<1,23,180>
<2,24,182>
<3,22,180>
<4,23,178>
<5,24,177>
<6,22,178>
<7,23,178>

The sorted array (descending order of age):
<2,24,182>
<5,24,177>
<1,23,180>
<4,23,178>
<7,23,178>
<3,22,180>
<6,22,178>

a)	What is the Java code you would use to define a new array called persons with storage for references to n Person objects?

b)	Write the pseudocode to create the 7 new people/persons and add them to the persons array.

c)	Write the pseudocode to display the data in the Persons array.

d)	What method will you use to get the ages of each person in your Person�s array when you have to compare the ages in your insertionSort() method?

e)	Write the insertionSort method to sort an array of Person objects in decreasing order of age.

f)	Develop the application in NetBeans:
i.	Create a new project call PersonArraySort.
ii.	Create a Person class (in a separate file). You did this for the Car class in an earlier tutorial (week 3).
iii.	Develop and test your program incrementally as follows:

Step 1: add the code for the instance variables, constructor and getters and setters described previously. Include the following toString() method to produce a String that represents  the person details in a sensible format. Note that id, age and height should be the names of the instance variables in your Person class.


@Override
public String toString() {
return "<"+id+","+age+","+height+">";
}

Note that the object�s toString() method will be invoked implicitly by print methods whenever the String representation of an object is required.  For example

System.out.println(persons[1]);

will output the string representation of persons[1] returned by its toString() method.

Step 2: Add the following code to your main method.

int n = 7;
int[] ids  =    { 1,   2,   3,   4,   5,   6,   7   };
int[] ages =    { 23,  24,  22,  23,  24,  22,  23  };
int[] heights = { 180, 182, 180, 178, 177, 178, 178 };


Step 3: Add the code to declare the array of Person objects

Step 5: Write the code to create the 7 new Person objects and add them to the persons array

Step 6: Display the persons array. (See the sample output for the final application below.)

Step 7: Add the code for the sort method  (in the class with the main() method).
It should be added as a new method after the main() method.

Step 8: In the main() method pass the persons array to the sort method (so that the array gets sorted).

Step 9: Display the sorted persons array

g)	What values would you need to test the program with to be confident that it works correctly?
*/

public class W08Q2PeopleArrayTester
{
	public static void sort (People[] peopleArray)
	{
		// Bubble Sort in Ascending order of age:
		// (Brute force, unoptimised code)
        for (int m = 0; m < peopleArray.length; m++)
        {
			for (int k = 0; k < peopleArray.length - 1; k++)
			{
				if (peopleArray [k].getAge() < peopleArray [k + 1].getAge() ) // Descending sort on Age
				{
					People temp         = peopleArray [k];
					peopleArray [k]     = peopleArray [k + 1];
					peopleArray [k + 1] = temp;
				}
			}
		}
	}

	public static void displayArray (People[] peopleArray)
	{
        for (int k = 0; k < peopleArray.length; k++)
        {
			System.out.println (peopleArray [k]);
		}
		System.out.println ("-> " + peopleArray.length + " people listed.");
	}

   public static void main(String[] args)
   {
	   // Parallel Arrays:
        int[] ids  =    {   1,   2,   3,   4,   5,   6,   7 };
        int[] ages =    {  23,  24,  22,  23,  24,  22,  23 };
        int[] heights = { 180, 182, 180, 178, 177, 178, 178 };

		// Create array of People:
        People[] peopleArray = new People [ids.length];

        for (int k = 0; k < peopleArray.length; k++)
        {
			People p = new People (ids[k], ages[k], heights[k]);

			peopleArray [k] = p;
		}

		System.out.println ("\n" + "People: unsorted data");
		displayArray (peopleArray);

		sort (peopleArray);

		System.out.println ("\n" + "People: sorted data in descending age order");
		displayArray (peopleArray);
   }
}