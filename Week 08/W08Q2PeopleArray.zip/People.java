/*
 Author: Mike O'Malley
 Source: People.java
Descrtn: Class data and methods for handling People objects.

Ammendment History
Ver   Date        Author    Details
----- ----------- --------  ---------------------------------------------------
0.001 09-Sep-2022 Mike O    Created.

*/
public class People
{

   // Class Data:
   private int     id;
   private int     age;
   private int     height;

   // Default Consructor:
   public People ()
   {
      id     = 0;
      age    = 0;
      height = 0;
   }

   // Parameterised Consructor:
   public People (int id, int age, int height)
   {
      this.id     = id;
      this.age    = age;
      this.height = height;
   }

   // Accessors / Getters:

   public int getId ()
   {
      return id;
   }

   public int getAge ()
   {
      return age;
   }

   public int getHeight ()
   {
      return height;
   }

   // Mutators / Setters:

   public void setId (int id)
   {
      this.id = id;
   }

   public void setAge (int age)
   {
      this.age = age;
   }

   public void setHeight (int height)
   {
      this.height = height;
   }

   @Override
   public String toString ()
   {
      return
         id     + "\t" +
         age    + "\t" +
         height + "\t" +
         "";
   }

} // People
