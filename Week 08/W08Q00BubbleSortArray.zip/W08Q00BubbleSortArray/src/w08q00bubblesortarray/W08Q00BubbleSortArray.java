/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package w08q00bubblesortarray;

/**
 *
 * @author omalleym
 */
public class W08Q00BubbleSortArray {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here
        int[] intArray = {77, 4, 5, 1, 64, 23, 88, 99, 101, 3};

        // Bubble Sort: Brute Force / Unoptimised (slightly simpler) version:
        for (int m = 0; m < intArray.length; m++) 
        {
            for (int k = 0; k < intArray.length - 1; k++) 
            {
                if (intArray[k] > intArray[k + 1]) // Assume Ascending Sort
                {
                    int temp        = intArray[k];
                    intArray[k]     = intArray[k + 1];
                    intArray[k + 1] = temp;
                }
            }
        }

        for (int k = 0; k < intArray.length; k++) 
        {
            System.out.print (intArray[k] + ", ");
        }
        System.out.println ();
    }
    
}
