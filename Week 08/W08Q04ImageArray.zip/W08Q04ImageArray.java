
public class W08Q04ImageArray {

    public static void main(String[] args) {
        int[][] image = {
            {   0, 200, 100},
            { 255,  16, 155},
            { 255, 255,  32},
            { 122,  22,  12}
        };

        // display the data in the image array

        // Hard-coding 3's is BAD - what if array changes ???
        /*
        for (int i = 0; i < 3; i++ ) {
            for (int j = 0; j < 3; j++ ) {
               System.out.printf("image[%d][%d] = %d%n", i, j, image[i][j]);
            }//end of inner for loop
        }// end of outer for loop
		*/

		// MUCH BETTER:
        for (int i = 0; i < image.length; i++ )  // size of array - number of rows
        {
            for (int j = 0; j < image[i].length; j++ ) // the number of columns in each row
            {
               System.out.printf("image[%d][%d] = %d%n", i, j, image[i][j]);
            }//end of inner for loop
        }// end of outer for loop

        /*
        Interested in exploring further:

        Canvas
        drawLine
        drawCircle
        draw ....
        drawString
        */
    }
}
