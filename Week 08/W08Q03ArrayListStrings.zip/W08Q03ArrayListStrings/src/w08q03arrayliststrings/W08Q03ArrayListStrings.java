/*
Question Three

Create a new project called ArrayListExample that creates an ArrayList of type String in the main() method. 
•	Add the names Tom, Dick and Harry to the ArrayList (in main)
•	Using the enhanced for loop print out these names (in main)
•	Remove Dick from the list and then add George.
•	Insert John into the beginning of the list
•	Predict what will be output if you display the list now
•	Use a traditional for loop to print out the updated list

*/
package w08q03arrayliststrings;

import java.util.ArrayList;

/**
 *
 * @author omalleym
 */
public class W08Q03ArrayListStrings 
{
    public static void main(String[] args) 
    {
        // TODO code application logic here
        
        ArrayList<String> names = new ArrayList<> ();
        names.add ("Tom");
        names.add ("Dick");
        names.add ("Harry");
        
        for (String s : names)
            System.out.print (s + ", ");
        System.out.println ();
    

        // Remove Dick from the list 
        //names.remove (1); // Remove 2nd item in ArrayList
        names.remove ("Dick"); // much better solution, we don't need to know the index of Dick
        
        // and then add George.
        names.add ("George");

        // Insert John into the beginning of the list
        names.add (0, "John");
    
        for (int k = 0; k < names.size(); k++)
            System.out.print (names.get(k) + ", ");
        System.out.println ();
    }
    
}
