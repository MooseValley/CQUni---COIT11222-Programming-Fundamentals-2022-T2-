/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
/*
DOS / Command Shell Command Line:

"C:\Program Files\Java\jdk-17.0.3.1\bin\java.exe" -jar "C:\Users\omalleym\OneDrive - CQUniversity\Documents\NetBeansProjects\W01Add\dist\W01Add.jar" 1 55 45 9
The total is: 110

Or in NetBeans:
Project -> Properties -> Run and type in "1 55 45 9" as arguments (no quotes)
and Run your program
The total is: 110



*/
/**
 *
 * @author omalleym
 */
public class W01Add {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        int[] numbers = new int [args.length];
        int total = 0;
        
        for (int k = 0; k < args.length; k++)
        {
            numbers[k] = Integer.parseInt (args[k]);
            
            //total = total + numbers[k];
            total += numbers[k];
        }
        
        System.out.println ("The total is: " + total);       
        
    }
    
}
