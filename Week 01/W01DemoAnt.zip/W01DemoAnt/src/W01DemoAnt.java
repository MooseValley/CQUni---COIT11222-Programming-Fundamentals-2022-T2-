
import java.util.Random;
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author omalleym
 */
public class W01DemoAnt {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here

        // Syntax Errors
        System.out.println ("Java + ANT program running ...");
        
        // Logic Errors
        // BODMAS
        int perimeter = 3 * (4 + 5); // Logic Error - should be 2 * ....
        
        
        Scanner kb = new Scanner (System.in);


        // Runtime Error: InputMismatchException

        /*
        System.out.println ("Enter an integer: ");
        //int val = kb.nextInt();
        
        // Or we can read input in as a String and convert it to an integer
        String inputStr = kb.nextLine();
        int val = Integer.parseInt (inputStr);
        
        System.out.println ("You entered: " + val);
        */
        
        /*
        Scanner commands:
        nextLine() - string - the complete line
        next()     - string - the next bunch of characters up to the next white space (tab, space, ...)
        nextInt()  - integer
        nextDouble - double
        hasNext()  - is there more input in the buffer ?
        etc
        
        Integer.parseInt
        Double.parseDouble
        */
        
        
        // Runtime Error: ArithmeticException: / by zero
        //int val2 = 100 / 0;
        
        // Runtime Errors: invalid inputs, calculations than cause +/- infinity, reading / writing files, etc ....
    
        // For Loops:
    
        //for (initializer; condition; updater) - all are optional !!
        
        // Scope: where does something exist, where is it accessible, ....
        // usually up to next enclosing brace or semi-colon ...
        for (int m = 0; m < 10; m++)    // m = m + 1
        {
            boolean valid = false;
            double avg = 0.0;
            
            System.out.print (m + ", ");
        }
        //System.out.println ("m = " + m); // ERROR: m no longer exists.
        //System.out.println ("avg = " + avg); // ERROR: avg no longer exists.


        int k = 0;
        
        for (k = 0; k < 10; k++)    // k = k + 1
        {
            System.out.print (k + ", ");
        }
        System.out.println ("k = " + k); // OK
        
        System.out.println ("perimeter = " +    perimeter); // OK
        
        System.out.println ();
        
        
        // Infinite Loops
        //for (;;);
        
        //for (int p = 0; p < 1;);

        //for (int p = 0; p < 1;);
        
        System.out.println ("1.21");
        /*
        for (int p = 0; p < 10; ) // p++
        {
            System.out.println ("Hello");
            System.out.println ("World");
            //p++;
            //p = p + 1;
        }
        */


        // How many times will we see "Hello" ??
        // How many times will we see "World" ??
        for (int p = 0; p < 10; p++)
        {
            System.out.println ("Hello");
            System.out.println ("World");
        }
        
        System.out.println ("1.22");
        for (int p = 0; p < 10; p++)
            System.out.println ("Hello");
            System.out.println ("World");

        System.out.println ("1.23");
        for (int p = 0; p < 10; p++)
        {
            System.out.println ("Hello");
            System.out.println ("World");
        }
        
        System.out.println ("1.24");
        for (int p = 0; p < 10; p++);
        {
            System.out.println ("Hello");
            System.out.println ("World");
        }

        System.out.println ("1.25");
        for (int p = 0; p < 10; p = p + 1)
        {
            System.out.println ("Hello");
            System.out.println ("World");
            //p++;
            //p = p + 1;
        }
        
        /*
        For Loop / aka Counter Controlled Loop
        for (int p = 0; p < 10; p++)
        for (int p = 0; p < 10; p = p + 1)
        
        */

        
        
        /*
        System.out.println ("1.26");
        double temperature = 0.0;
        double total = 0.0;
        int count = 0;
        for (; temperature < 100;)
        {
            System.out.println ("Enter a temperature: ");
            temperature = kb.nextDouble();

            total = total + temperature;
            count++;
        }
        System.out.println ("Average = " + (total / count) );
        
        
        // Do the same with a while loop ....
        // Re-initialize variables that are still in scope
        
        System.out.println ("1.27");
        temperature = 0.0;
        total = 0.0;
        count = 0;
        while (temperature < 100)
        {
            System.out.println ("Enter a temperature: ");
            temperature = kb.nextDouble();

            total = total + temperature;
            count++;
        }
        System.out.println ("Average = " + (total / count) );
        */
       
        // while and multiple conditions:
        // && = AND
        // || = OR 
        //while ((temperature < 100) && (planet == 3) ) // Both must be true to keep looping
        //while ((temperature < 100) || (planet == 3) ) // Either must be true to keep looping
        //for (; ((temperature < 100) || (planet == 3) );)


        /*
        Compile and test often - Incremental Development
        Write a few lines of code and then compile and test
        Write a few more lines of code and then compile and test
        Write a few more lines of code and then compile and test
        
        The absolute last thing you want to be doing:
        Write dozens or more lines of code and then compile and test
        -> by then you could have many errors to sort out.
        
        
        Keep regular backups.
        Backup to multiple places - external USB harddrives, the cloud (OneDrive, etc), thumb drives, draft emails, etc
        Get in the habbit of this.
        As an IT Professional, you are going to look very stupid / lame / incompetent
        if you lose work as not keeping regular, proper backups.
        Don't rely on others keeping backups for you.
        Even for relatively trivial stuff like tutorial work ...
        
        */
        
        
        /* 
        Command Line Parameters:
        
        public static void main(String[] args)
        
        args contains an array of Strings
        
        // Arrays:
        Want to store 5 temperatures:
        double temp1, temp2, temp3, temp4, temp5;
        double average = (temp1 + temp2 + .... + temp5) / 5;

        Want to store 15 temperatures: ... can expand the above

        Want to store 1000 or a million temperatures: ... ????
        Madness to use the above technique !!!!
        
        Use arrays !!
        
        double[] tempArray = new double [1000]; // can store 1000 temperatures

        // Valid index locations are 0 ... 999
        tempArray[0]
        :::
        tempArray[999]
        
        An Array is a collection of data stored under a single name and 
        accessed with square brackets [] and a valid integer value in the required range.
        
        Think of a row of numbered mailboxes or pidgeon holes.
        
        */
            
        System.out.println ("");
        System.out.println ("2.0 - Arrays");
        double[] tempArray = new double [50000]; // can store many temperatures
        
        Random rand = new Random();
        for (int m = 0; m < tempArray.length; m++)
        {
            tempArray[m] = rand.nextInt(144); // 0 to 143 inclusive
        }

        double totalTemp = 0.0;
        double average = 0.0;
        for (int m = 0; m < tempArray.length; m++)
        {
           totalTemp = totalTemp + tempArray[m];
        }
        average = totalTemp / tempArray.length;
        
        System.out.println ("Average = " + average);

        
        // Comments in Java
        // Comments are programmers notes explaining what the code does, TODO lists, etc
        // Comments are completely ignored by the compiler
        // everthing after the // is a comment
        /* everything between the slash star and star slash is a comment */
        /* 
            everything between 
            the slash star and 
            star slash 
            is a comment 
        */
        
        System.out.println ("2.1 - Hard-coded Arrays");
        double[] temps  = {8.2, 3.3, 3.9};
        String[] places = {"Rockhampton", "Bundaberg", "New York", "Delhi"};
        
        for (int m = 0; m < places.length; m++)
            System.out.println (places[m]);
        
        /*
        *** Your Bucket List:
        1. Visit Venice
        2. Hanging Gardens of Babylon
        3. Pyramids in Egypt
        4. Myan Temples
        5. Uluru Australia
        */
        System.out.println ("2.2 - Arrays - Input and Display");
        String[] bucketList = new String[5];
        for (int m = 0; m < bucketList.length; m++)
        {
            System.out.println ("Enter Bucket List item [" + (m+1) + "]: ");
            bucketList[m] = kb.nextLine();
        }
        
        System.out.println ("*** Your Bucket List:");
        for (int m = 0; m < bucketList.length; m++)
        {
            System.out.println ((m+1) + ". " + bucketList[m]);
        }
        
        
        
        
    }
}
