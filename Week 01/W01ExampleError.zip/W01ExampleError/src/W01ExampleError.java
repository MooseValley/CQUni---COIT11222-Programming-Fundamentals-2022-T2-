/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author omalleym
 */
public class W01ExampleError {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int x = 1;
        int y = 3;
        int z = x+y;
        System.out.println ("z=" + z);
        
        String name = "Mike";
        String location = "Rockhampton";
        int age = 21;
        
        System.out.println (name + " is " + age + " years old and lives in " + location);
        
        name = "Frankie";
        location = "Yeppoon";
        age = 2;
        System.out.println (name + " is " + age + " years old and lives in " + location);
        
    }
    
}
