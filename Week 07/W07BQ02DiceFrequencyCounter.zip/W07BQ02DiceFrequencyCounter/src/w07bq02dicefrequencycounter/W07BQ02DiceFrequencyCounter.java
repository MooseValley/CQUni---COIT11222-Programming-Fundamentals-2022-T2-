/*
Question 2 
Suppose that you are recording the outcomes of a number of rolls of a single dice in an array. What length would you make the array?

 */
package w07bq02dicefrequencycounter;

import java.util.Random;

/**
 *
 * @author omalleym
 */
public class W07BQ02DiceFrequencyCounter {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here
        
        /*
        Declare an arrray to hold a count of all possible outcomes
        Loop ??? times
            generate a random number (1-6)
            increment frequency for that dice value (outcome)
        Display frequency table / results
        */
        
        int MAX_INT  = 6;
	Random rand  = new Random();
        int[] counts = new int [MAX_INT];
        int   total  = 0;

        for (int k = 0; k < 1_000_000; k++)
        {
            int diceRoll = rand.nextInt (6); // 0 to 5
            
            counts [diceRoll]++;
            total++;
        }
        
        System.out.println ("For " + String.format ("%,d", total) + " rolls of the dice:");
        for (int k = 0; k < counts.length; k++)
        {
            System.out.println ((k+1) + ": " + String.format ("%,d", counts[k]) );
        }
        
        /* 
        Random generates poor quality random numbers, the seed can be guessed, can be broken / cracked => next number guessed !
        Use SecureRandom class instead.  Especially if money is involved.
        */
    }
}
