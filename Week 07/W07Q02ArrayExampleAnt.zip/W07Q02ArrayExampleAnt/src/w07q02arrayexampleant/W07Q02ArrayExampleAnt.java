/*
Question Two (ArrayExample)

(a)	Create a new project called ArrayExample. In the main() method of the new project, declare and create an array  of ints called numbers with the following values: 

    42, 56, 34, 27, 72, 12, 98, 85, 33, 67

(b)	Add a for loop which traverses the array and outputs the numbers on one line separated by spaces.

(c)	Add an enhanced for loop which does the same as part b.

(d)	Add a loop which finds the total value of all the values in the array and also finds the minimum and 
maximum value stored in the array. 

Hint: The Integer class has two constants – one for the maximum integer value and one for the minimum integer value. 
When finding the maximum and minimum integer values stored in the array, you can therefore initialize maximum and 
minimum as follows:
    int minimum = Integer.MAX_VALUE;
    int maximum = Integer.MIN_VALUE;
		  
Or alternatively, you could set them to the first value in the array and begin iteration from the second   element.

(e)	Write a method search() which will accept the array as a parameter and an integer (key) as a parameter. 
The  method is to search the array for the key value and return the index of the found value or -1 
if the  value is not found. 

public static int search(int [] arr, int key)

(f)	Add code to prompt the user for a value to be searched for in the array, read the value from the 
user then use the search() method you wrote to search for it. The result returned from the search method 
is to be used to either output a message to indicate that the value was not found or a message to indicate 
the index in the array where the value was found.

 */
package w07q02arrayexampleant;

import java.util.Scanner;

/**
 *
 * @author omalleym
 */
public class W07Q02ArrayExampleAnt {

    public static int search (int [] arr, int key)
    {
        int index = -1; // Not found

        for (int k = 0; k < arr.length; k++)
        {
            if (arr [k] == key)
            {
                index = k; // Found
                k = arr.length; // Exit loop
            }
        }

        return index;
    }

        
    public static void main (String[] args)
    {
        int[] ints = {42, 56, 34, 27, 72, 12, 98, 85, 33, 67}; // 10
        
        for (int k = 0; k < ints.length; k++)
        {
            System.out.print (ints [k] + ", ");
        }
        System.out.println ();

        for (int i : ints)
        {
            System.out.print (i + ", ");
        }
        System.out.println ();
        

        int minimum = Integer.MAX_VALUE;
        int maximum = Integer.MIN_VALUE;
        int total = 0;
        
        for (int k = 0; k < ints.length; k++)
        {
            total += ints [k];
            
            if (minimum > ints [k])
                minimum = ints [k];

            if (maximum < ints [k])
                maximum = ints [k];
        }
        System.out.println ("total: " + total + ", minimum: " + minimum + ", maximum: " + maximum);
        
        // For Testing:
        //System.out.println ("Searching for '12' ... result: " + search (ints, 12) );
        //System.out.println ("Searching for '33' ... result: " + search (ints, 33) );
        
        Scanner kb = new Scanner (System.in);
        
        System.out.print ("Enter search key: " );
        int key = kb.nextInt ();
        
        int result = search (ints, key);
        
        if (result >= 0)
            System.out.println (" <-- Found !");
        else
            System.out.println (" <-- NOT Found !");
    }    
}
