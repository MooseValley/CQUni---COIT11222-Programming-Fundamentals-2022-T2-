/*
Question Four
You are to use a one-dimensional array to implement the code to solve the following problem:
A company pays its salespeople on a commission basis. 
The salespeople receive $200 per week plus 10% of their gross sales for that week. For example, a salesperson who grosses $5000 in 
sales in a week receives $200 plus 10% of $5000, for a total of $700. 

The application is to calculate the salaries for each salesperson and determines how many of the salespeople earned salaries in
each of the following ranges (assume that each salesperson's salary is truncated to an integer amount):
•	$200-299 
•	$300-399 
•	$400-499 
•	$500-599 
•	$600-699 
•	$700-799 
•	$800-899 
•	$900-999 
•	$1000 and over

Hint 1: This is a similar concept to the example where we worked out the number or frequency of each unit evaluation 
score in the lectures. However, this time we can use integer division to divide the salary by 100 to get an index in the 
range 2 – 10.  You should have a special case to cater for anything greater than $1000.  

Salary range	Index to access the frequency array
Use (salary /100) to get the index into “frequency” array
(given the specification you will only use indexes 2 to10)
$200-299 	2
$300-399 	3
$400-499 	4
$500-599 	5
$600-699 	6
$700-799 	7
$800-899 	8
$900-999	9
$1000 and over 	If result is >=10 index of 10 should be used

For this exercise you can assume 10 salespeople and that rather than reading in the sales for each of the salespeople, you can initialise the sales data in an array. An example of such an array follows. (The data can be changed when you test your application.)
Int [] sales = {500, 1500, 2500, 3500, 4500, 5500, 6500, 7500, 8500, 9500}; //sales for 10 salespersons
This means you can use a for loop in your pseudocode to process each data item in the array similar to the following:

FOR each sales amount in the array of sales data
    :
    :

The results are to be summarised in tabular form similar to the sample output below:

Salary Range     Number
                 in the range
-----------------------------
$200-299          0
$300-399          2
$400-499          3
$500-599          0
$600-699          1
$700-799          0
$800-899          1
$900-999          1
$1000(and over)   2

Hint 2 (printing out each range): When you use a for loop to display the number of salaries in each range, assuming your loop counter is i then the lower bound of the range is i *100 and the higher bound will be the lower bound + 99. Salary ranges of $1000 and over will have to be output as a special case. 
      
(a)	What output should be generated with the sample data provided previously (and reproduced below)?

  Int [] sales = {500, 1500, 2500, 3500, 4500, 5500, 6500, 7500, 8500, 9500}; //sales for 10 salespersons

(b)	Write the pseudocode for this application.

(c)	Create a new project called SalaryFrequencies

Implement the pseudocode you developed for the application to work out salaries and their frequencies in the previous question.  

Remember to develop and test your application incrementally (e.g. step 1 would be to print out the sales and the salary for each salesperson, step 2 would be to build and display the frequency table showing the number of salaries in each salary range etc..)


(d)	What values would you need to test the program with to be confident that it works correctly?

 */
package w07q04salespersonsalaryfrequencychart;

/**
 *
 * @author omalleym
 */
public class W07Q04SalesPersonSalaryFrequencyChart {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        /* 
            NOTE: 
              * My code deviates from the question.  
              * I wanted to have arrays of lower and upper limits and do things properly
                and not take the short cuts / simplifications in the question above.
              * And Sales, etc should all be doubles not ints.
              * And I added in more Sales valus => more sales people.
            Mike O       
        */
        
        double[] sales               = {500, 1500, 2500, 3500, 4500, 5500, 6500, 7500, 8500, 9500}; 
        //double[] sales               = {500, 300, 800, 700, 2400, 2350.2, 195.77, 4433, 6688, 7300, 7400, 7700, 7844, 1500, 2500, 3500, 4500, 5500, 6500, 7500, 8500, 9500, 9300, 9200, 9040.33, 9020}; 
        double[] lowerLimits         = {200, 300, 400, 500, 600, 700, 800, 900, 1000};
        double[] upperLimits         = {299, 399, 499, 599, 699, 799, 899, 999, Integer.MAX_VALUE};
        int[]    salaryFrequency     = new int    [lowerLimits.length];
        double[] salesPersonSalaries = new double [sales.length]; 
        
        if (lowerLimits.length != upperLimits.length)
        {
            System.out.println ("INTERNAL ERROR: arrays must have the same number of elements.  Ref: lowerLimits and upperLimits.");
            System.exit (-1);
        }
        
        // Calculate salesPersonSalaries and
        // Display sales and salesPersonSalaries - so I can check results are correct
        System.out.println ("Sales         Income");
        for (int k = 0; k < sales.length; k++)
        {
            salesPersonSalaries [k] = 200.0 + 10.0 / 100.0 * sales [k];
            
            System.out.println ("$" + String.format("%,10.2f", 1.0 * sales [k]) + "   " + "$" + String.format("%,10.2f", salesPersonSalaries [k]) );
        }
        
        
        // Calculate salaryFrequency of salesPersonSalaries
        for (int k = 0; k < sales.length; k++)
        {
            for (int m = 0; m < lowerLimits.length; m++)
            {
                if ((salesPersonSalaries[k] >= lowerLimits [m]) && (salesPersonSalaries[k] <= upperLimits [m]) )
                {
                    salaryFrequency [m]++;
                    m = lowerLimits.length; // Exit inner loop
                }
            }
        }

        // Display salaryFrequency results:
        System.out.println ("\n" + "    Range      Frequency");
        for (int m = 0; m < lowerLimits.length; m++)
        {
            if (m < lowerLimits.length - 1)
                System.out.println (String.format("%,6.0f", lowerLimits[m]) + "-" + String.format("%,.0f", upperLimits[m]) + "    " + String.format("%6d", salaryFrequency[m]) );
            else
                System.out.println (String.format("%,6.0f", lowerLimits[m]) + "-> ...  "                                            + String.format("%6d", salaryFrequency[m]) );
        }


    }
    
}
