/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w05q02carapp;

/**
 *
 * @author omalleym
 */
public class Car {
    
    private String model;
    private String year;

    public Car(String m, String y){
        model = m;
        year = y;
    }

    public String getModel(){
        return model;
    }

    public String getYear(){
        return year;
    }
}
