/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w05q02carapp;

/**
 *
 * @author omalleym
 */
public class W05Q02CarApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        Car car1 = new Car("Honda", "2021");
        Car car2 = new Car("Honda", "2021");

        //if (car1 == car2)                          // Logic Error: comparing memory addresses !
        //if (car1.getModel() == car2.getModel())    // Logic Error: comparing memory addresses !  We are NOT comparing data.
        //if (car1.getModel().equals (car2.getModel() )    == true) // OK
        if (car1.getModel().compareTo (car2.getModel() ) == 0)    // OK
        {
          System.out.println(car1.getModel()+" is equal to " +    
                             car2.getModel());
        }
        else
        {
          System.out.println(car1.getModel()+" is NOT equal to "          
                             +car2.getModel());
        }

    }
    
}
