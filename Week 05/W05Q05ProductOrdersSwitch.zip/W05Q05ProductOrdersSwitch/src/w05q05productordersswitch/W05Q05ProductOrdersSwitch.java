/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w05q05productordersswitch;

import java.util.Scanner;

/**
 *
 * @author omalleym
 */
public class W05Q05ProductOrdersSwitch {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here
        
        /*
        Specification:
        A mail-order house sells five products whose retail prices are as follows: product 1, $2.99; product 2, $4.50; 
        product 3, $9.99; product 4, $4.49 and product 5, $7.00.   Product class.
        */
        Product p1 = new Product ("Corn Flakes", 2.99);
        Product p2 = new Product ("All Bran",    4.50);
        Product p3 = new Product ("Muesli",      9.99);
        Product p4 = new Product ("Wheat Bix",   4.49);
        Product p5 = new Product ("Rolled Oats", 7.00);
        

        /*
        The retail value of the purchase is to be calculated and displayed. Use a switch statement to determine the 
        retail price for each product purchased. No processing is to be performed if the product code is invalid or if 
        the quantity entered is zero or negative. In both situations, an error message is to be displayed. Sample output is shown below:

        Sample Output
            Enter the product number (1 - 5): 4
            Enter the number sold: 10
            Sold 10 items of product id: 4 at $4.49 each. Total cost = $44.90
        */
        
        Scanner kb = new Scanner (System.in);

        System.out.print ("Enter Product number (1-5): ");
        int productNum = kb.nextInt();
        
        System.out.print ("Enter the number sold: ");
        int numSold = kb.nextInt();
        

        //******************************************************************************
        double price = 0.0;
        String prodName = "";
        
        switch (productNum)
        {
         case 1:
           price = p1.getPrice();
           prodName = p1.getName();
           break;
         case 2:
            price = p2.getPrice();
            prodName = p2.getName();
            break;
         case 3:
            price = p3.getPrice();
            prodName = p3.getName();
            break;
         case 4:
            price = p4.getPrice();
            prodName = p4.getName();
            break;
         case 5:
            price = p5.getPrice();
            prodName = p5.getName();
            break;
         default:
            price = 0;
            prodName = "";
            System.out.println("Invalid product number. Must be 1-5");
            break;
        };

        if (prodName.length() > 0)
        {
            double totalCost = price * numSold;
            
            System.out.println("Sold " + numSold + " items of " + prodName + " (product id: " + productNum + ") at $" +
                    String.format ("%.2f", price) + " each. Total cost = $" + String.format ("%.2f", totalCost) );
        }
        
        //******************************************************************************
        
        /*
        *** Homework: Week 5 Q05 - Mike O's Extras
        
        Create an Order class
        get inputs from user - productId, num sold, and use these to create an Order object
            Order order = new Order (.......);
        
        and then use this to lookup the product details and calculate the totals / generate the output:
            System.out.println(order.toString() );

        Everything between the ***** above should go into Order class methods.
        
        Bring along to next class and discuss if any issues !!
        */
        

    }
    
}
