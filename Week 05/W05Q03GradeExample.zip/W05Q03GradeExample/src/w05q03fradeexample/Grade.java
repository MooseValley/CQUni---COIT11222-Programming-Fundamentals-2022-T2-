/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w05q03fradeexample;

/**
 *
 * @author omalleym
 */
public class Grade 
{
    private String name;    // Instance fields.  Class scope: any instance method in the class can access them
    private String studId;
    private int ass1;
    private int ass2;
    private int ass3;
    private int total;
    private String gradeStr;
    
    public Grade (String name, String studId, int ass1, int ass2, int ass3)
    {
        this.name   = name;
        this.studId = studId;
        this.ass1   = ass1;
        this.ass2   = ass2;
        this.ass3   = ass3;
        
        // Work out Total
        total = ass1 + ass2 + ass3;
        
        // Work out Grade
        if ((total < 0) || (total > 100) )
        {
            System.out.println ("ERROR: Total mark (" +  total + ") must be between 0 and 100 incl.");
        }
        else
        {
            gradeStr = "";
            if (total < 50)       gradeStr = "F";
            else if (total < 65)  gradeStr = "P";
            else if (total < 75)  gradeStr = "C";
            else if (total < 85)  gradeStr = "D";
            else                  gradeStr = "HD";
        }
    }
    
    public String toString ()
    {
        return "Student: " + name + " (" + studId + ") scored " + total + 
               " overall and achieved a '" + gradeStr + "'.";
    }
    
}
