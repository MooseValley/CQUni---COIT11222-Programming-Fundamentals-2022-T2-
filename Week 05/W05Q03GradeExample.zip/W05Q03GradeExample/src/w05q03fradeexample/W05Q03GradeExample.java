/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w05q03fradeexample;

import java.util.Scanner;

/**
 *
 * @author omalleym
 */
public class W05Q03GradeExample {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner kb = new Scanner(System.in);
        
        // Prompt the user for the student id
        // Read the student id
        System.out.print ("Enter Student Id: ");
        String studIdStr = kb.nextLine();

        // Prompt the user for the student name
        // Read the student name
        System.out.print ("Enter Student Name: ");
        String studNameStr = kb.nextLine();

        // Prompt for and read the three assignment marks
        System.out.print ("Enter 3 assignment marks: ");
        int ass1 = kb.nextInt();
        int ass2 = kb.nextInt();
        int ass3 = kb.nextInt();
        
        /*
        // Calculate the total mark
        int total = ass1 + ass2 + ass3;
        
        /*
         IF total is greater than 100 or less than 0 
           Print an error message to the user 
        ELSE
            Work out the grade based on the total mark (use if .. else statements to do this)
            Display the total mark and grade for the student
        
        •	Grade F for Total Mark< 50
        •	Grade P for 50 <= Total Mark< 65
        •	Grade C for 65 <= Total Mark< 75
        •	Grade D for 75 <= Total Mark< 85
        •	Grade HD for Total Mark >= 85
        */

        /*
        System.out.println ();
        if ((total < 0) || (total > 100) )
        {
            System.out.println ("ERROR: Total mark (" +  total + ") must be between 0 and 100 incl.");
        }
        else
        {
            String gradeStr = "";
            if (total < 50)       gradeStr = "F";
            else if (total < 65)  gradeStr = "P";
            else if (total < 75)  gradeStr = "C";
            else if (total < 85)  gradeStr = "D";
            else                  gradeStr = "HD";
            
            System.out.println ("Student: " + studNameStr + " (" + studIdStr + ") scored " + total + 
                                " overall and achieved a '" + gradeStr + "'.");
        }
        */
        
        Grade grade = new Grade (studNameStr, studIdStr, ass1, ass2, ass3);
        //System.out.println (grade.toString() );
        System.out.println (grade); // Java automatically looks for and calls toString()
                

    }
    
}
