/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w05q01eoutput;

/**
 *
 * @author omalleym
 */
public class W05Q01EOutput {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        int x = 10, y = 9;    
        x=10; y=11;
        x=9; y=8;
        
        if (x >=10) 
        if (y <10)
        System.out.println("statement 1");
        else
        System.out.println("statement 2");
        System.out.println("statement 3");            


        // v2
        if (x >=10) 
        {
            if (y <10)
                System.out.println("statement 1");
            else
                System.out.println("statement 2");
        }
        
        System.out.println("statement 3");            

        
        // v3
        if (x >=10) 
        {
            if (y <10)
            {
                System.out.println("statement 1");
            }
            else
            {
                System.out.println("statement 2");
            }
        }
        
        System.out.println("statement 3");            


    }
    
}
