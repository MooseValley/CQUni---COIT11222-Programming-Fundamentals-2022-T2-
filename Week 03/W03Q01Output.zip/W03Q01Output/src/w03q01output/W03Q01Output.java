/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w03q01output;

/**
 *
 * @author omalleym
 */
public class W03Q01Output {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

       int age = 10;
       double amount = 310.5692;
       String name = "David";


         System.out.printf("age = %d ", age);
         System.out.printf("amount = %f%n", amount);
         System.out.printf("Name: %s age: %d%n amount: %.3f%n", name, age, amount);

    }
    
}
