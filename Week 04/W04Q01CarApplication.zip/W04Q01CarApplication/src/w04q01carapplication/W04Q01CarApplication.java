/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w04q01carapplication;

/**
 *
 * @author omalleym
 */
public class W04Q01CarApplication {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here
        
        Car c1 = new Car ();
        
        Car c2 = new Car ("Honda", "2002", 19990.99);
        Car c3 = new Car ("Honda ZIP");
        
        //c2.price = 10000.0;
        
        double currPrice = c2.getPrice();
        double newPrice  = currPrice * (1.0 - 0.05);
        c2.setPrice (newPrice);
        
        // Or all on one line of code:
        c2.setPrice (c2.getPrice() * (1.0 - 0.05) );
        
        /*
        System.out.println ("Car c1: Make: " + c1.getModel() + ", Year: " + c1.getYear() + 
                            ", Price: $" + String.format ("%,.2f", c1.getPrice() ) );

        System.out.println ("Car c2: Make: " + c2.getModel() + ", Year: " + c2.getYear() + 
                            ", Price: $" + String.format ("%,.2f", c2.getPrice() ) );
        
        System.out.println ("Car c3: Make: " + c3.getModel() + ", Year: " + c3.getYear() + 
                            ", Price: $" + String.format ("%,.2f", c3.getPrice() ) );
        */
        
        c3.setPrice (-100.0);
        
        
        System.out.println ("Car c1: " + c1.toString() );
        System.out.println ("Car c2: " + c2.toString() );
        System.out.println ("Car c3: " + c3.toString() );
        
    }
    
}
