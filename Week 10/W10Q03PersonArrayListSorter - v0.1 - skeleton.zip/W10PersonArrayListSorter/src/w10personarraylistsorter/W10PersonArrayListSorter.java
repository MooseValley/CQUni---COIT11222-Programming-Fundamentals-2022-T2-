/*
Simplified Q3

1. Create PersonArrayList from data arrays
2. Sort the ArrayList by lastname
3. Display the sorted arraylist

 */
package w10personarraylistsorter;

/**
 *
 * @author omalleym
 */
public class W10PersonArrayListSorter {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here
        String[] firstNames  =    { "Jacquie",   "Catherine",   "Mairi",   "Barbara",   "Vanessa",    "Megan",   "Dennis"};
        String[] lastNames = {"Jarvis", "Rutherford", "Jarvis", "Anderson", "Baker", "Baker", "Jarvis"};
        int[] ages =    { 23,  24,  22,  23,  24,  22,  23  };
        int[] heights = { 180, 182, 180, 178, 177, 178, 178 };

        ArrayList<????> personArrayList = new ........
        
        // 1. Create PersonArrayList from data arrays
        for (.....)
        {
            Person p = new Person (.....);
            personArrayList.???? (????);
        }
        
        // 2. Sort the ArrayList by lastname: BubbleSort, InsertionSort, whatever sort you like.
        for (.....)
        {
            for (.....)
            {
                if (?????)
                {
                    // swap people
                }
            }
        }
        
        // 3. Display the sorted arraylist
        for (.....)
        {
            ??????
        }

    }
    
}
