/*
Question 1
We are going to use our Car class from Week 4 again in this application. 
Requirements:
The Car class has three instance variables – a model (type String) a year (type String) and a price (type double). 
It has a constructor that initializes the three instance variables. 

However, in this version you are to have the Car constructor throw an IllegalArgumentException exception if the price is <=  0. 

The main method is to:
•	prompt the user for the model, year and price. 
•	use the Car class’s constructor to create a new Car object. If the price passed to the constructor 
is invalid (<=0), the constructor is to throw an IllegalArgumentException. The main method is to include the 
code to catch the exception should it occur andprovide the user with an appropriate error message explaining 
the problem and prompt the user for  another value.  The loop to read the price data is to terminate when the
user has entered valid data for the price and a valid Car object has been created. 

Mike O's Note: Main program does the looping / retrying – not the Constructor




•	Outside the loop that is used to read the price data, display the details of the new car object that has been created. 

Sample output for is shown below (data entered by user shown in bold):

Enter the model: honda
Enter the year: 2021
Enter the price: -8
Price must be > 0
Enter the price: 30000
New car model: honda year: 2021 price: $30000.00

(a)	Write the pseudocode for the main method (Hint: A do … while loop is appropriate. Why?)

(b)	Design the test data for this application.

(c)	Create a new project called CarExceptionDemo. Implement the code for the Car application. 

(d)	Test the code thoroughly.


Mike O's extra validation:
* Model must be at least 3 chars long


 */
package w10q01carexceptiontester;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author omalleym
 */
public class W10Q01CarExceptionTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here
        Scanner kb      = new Scanner (System.in);
        String modelStr = "";
        String yearStr  = "";
        double price    = 0.0;
        Car c           = new Car ();
        boolean valid   = false;
        
        while (valid == false)
        {
            try
            {
                System.out.print ("Enter Model: ");
                modelStr = kb.nextLine();
                c        = new Car (modelStr, yearStr, price); // Incomplete car data
                valid    = true;
            }
            catch (IllegalArgumentException err)
            {
                System.out.println ("Error: Mopdel must be at least 3 chars long.");                
            }
        }


        System.out.print ("Enter Year: ");
        yearStr = kb.nextLine();

        valid   = false;
        while (valid == false)
        {
            try
            {
                System.out.print ("Enter Price: ");
                price = kb.nextDouble();
                c     = new Car (modelStr, yearStr, price); // Complete car's data
                valid = true;                
            }
            //catch (InputMismatchException | NumberFormatException err)
            //catch (Exception err)
            //{
            //    System.out.println ("Error: price must be a number >= 0.");                
            //}
            catch (InputMismatchException err)
            {
                System.out.println ("Error: price must be numeric.");  // nextDouble                           
            }
            catch (NumberFormatException err) // Price < 0 throw ...
            {
                System.out.println ("Error: price must be a number >= 0.");                                
            }

            kb.nextLine(); // Clear Input buffer
        }
        
        System.out.println ("\n" + c + "\n");
    }
}
