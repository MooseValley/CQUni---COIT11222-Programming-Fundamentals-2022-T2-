/*
 Author: Mike O'Malley
 Source: Car.java
Descrtn: TBA ... :)

Ammendment History
Ver   Date        Author    Details
----- ----------- --------  ---------------------------------------------------
0.001 05-Aug-2022 Mike O    Created.

*/

package w10q01carexceptiontester;


public class Car
{
   // Class Data:
   private String  model;
   private String  year;
   private double  price;

   // Default Consructor:
   public Car () 
   {
      //model = "";
      //year  = "";
      //price = 0.0;
      this("unknown", "", 0.0);
   }

   // Parameterised Consructor #1:
   public Car (String model, String year, double price) 
   {
      // Do validations first, so that we don't have a class object made up of invalid data.
      // This ensures each class object contains valid data.
      //if (price >= 0.0)
      //  this.price = price;
      
      if (model.length() < 3)
          throw new IllegalArgumentException();
      
      if (price < 0.0)
          throw new NumberFormatException ();

      this.model = model;
      this.year  = year;
      this.price = price;
   }
   
   /*
   public Car (String modelA, String yearA, double priceA)
   {
      model = modelA;
      year  = yearA;

      if (priceA >= 0.0)
        price = priceA;
   }
   */


   // Parameterised Consructor #2:
   public Car (String model)
   {
      //this.model = model;
      //this.year  = "";

      //if (price >= 0.0)
      //  this.price = 0.0;
      
       this(model, "", 0.0);
   }
   

   // Accessors / Getters:

   public String getModel ()
   {
      return model;
   }

   public String getYear ()
   {
      return year;
   }

   public double getPrice ()
   {
      return price;
   }

   // Mutators / Setters:

   public void setModel (String model)
   {
      this.model = model;
   }

   public void setYear (String year)
   {
      this.year = year;
   }

   public void setPrice (double price)
   {
      if (price >= 0.0)
        this.price = price;
   }

   @Override
   public String toString ()
   {
      return 
            "Make: "   + String.format ("%-15s",   model)   + " " +
            "Year: "   + String.format ("%-5s",    year)    + " " +
            "Price: $" + String.format ("%,11.2f", price);
   }

} // Car
