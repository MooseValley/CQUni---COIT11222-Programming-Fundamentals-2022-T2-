/*
Simplified Q3

1. Create PersonArrayList from data arrays
2. Sort the ArrayList by lastname
3. Display the sorted arraylist

 */
package w10personarraylistsorter;

import java.util.ArrayList;

/**
 *
 * @author omalleym
 */
public class W10PersonArrayListSorter {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here

        // Parallel Arrays
        String[] firstNames  = { "Jacquie",   "Catherine",   "Mairi",   "Barbara",   "Vanessa",    "Megan",   "Dennis"};
        String[] lastNames   = {"Jarvis", "Rutherford", "Jarvis", "Anderson", "Baker", "Baker", "Jarvis"};
        int[] ages           = { 23,  24,  22,  23,  24,  22,  23  };
        int[] heights        = { 180, 182, 180, 178, 177, 178, 178 };

        ArrayList<Person> personArrayList = new ArrayList<> ();
        
        // 1. Create PersonArrayList from data arrays
        for (int k = 0; k < firstNames.length; k++)
        {
            Person p = new Person (lastNames[k], firstNames[k], ages[k], heights[k]);
            personArrayList.add (p);
        }
        
        // 2. Sort the ArrayList by lastname: BubbleSort, InsertionSort, whatever sort you like.
        boolean swapped = true;
        
        //for (int k = 0; k < personArrayList.size(); k++)  // Unoptimised
        while (swapped == true)                             // Semi-optimised
        {
            swapped = false;
            
            for (int m = 0; m < personArrayList.size() - 1; m++)
            {
                // Is this person's last name > next person's last name ??
                // OR if lastnames match, sort by firstnames
                if ((personArrayList.get(m).getLastName().compareToIgnoreCase (personArrayList.get(m + 1).getLastName()) > 0)      ||
                    ((personArrayList.get(m).getLastName().compareToIgnoreCase  (personArrayList.get(m + 1).getLastName())   == 0) &&
                     (personArrayList.get(m).getFirstName().compareToIgnoreCase (personArrayList.get(m + 1).getFirstName())  >  0) ) )
                {
                    // Swap people
                    Person temp = personArrayList.get(m);
                    personArrayList.set (m,   personArrayList.get(m + 1) );
                    personArrayList.set (m+1, temp);
                    
                    swapped = true;
                }
            }
        }
        
        // 3. Display the sorted arraylist
        for (int k = 0; k < personArrayList.size(); k++)
        {
            System.out.println (personArrayList.get(k) );
        }

    }
    
}
