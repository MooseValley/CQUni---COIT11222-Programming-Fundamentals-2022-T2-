/*
Person p1 = new Persion();                            // Call Default Constructor
Person p2 = new Person ("OMalley", "Mike", 100, 100); // Call Parameterised Constructor #1
Person p3 = new Person ("OMalley", "Mike");           // Call Parameterised Constructor #2

*/
package w10personarraylistsorter;

/**
 *
 * @author omalleym
 */
public class Person 
{
    private String lastName;
    private String firstName;
    private int age;
    private int height;

    // Default Constructor (no parameters constructor)
    public Person()   
    {
        this ("", "", 0, 0);   // Call Parameterised Constructor #1
    }

    // Parameterised Constructor #1
    public Person(String lastName, String firstName, int age, int height) {
        this.lastName = lastName;
        this.firstName = firstName;
        this.age = age;
        this.height = height;
    }

    // Parameterised Constructor #2
    public Person(String lastName, String firstName) {
        this (lastName, firstName, 0, 0);  // Call Parameterised Constructor #1
    }


    public String getLastName() {
        return lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public int getAge() {
        return age;
    }

    public int getHeight() {
        return height;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    @Override
    public String toString() {
        return "Person{" + "lastName=" + lastName + ", firstName=" + firstName + ", age=" + age + ", height=" + height + '}';
    }
    
    
}
