/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.w09q05stringvsstringbuffer;

/**
 *
 * @author omalleym
 */
public class Tester 
{
    public static void main (String[] args)
    {
        System.out.println ("String START");
        String s = "";
        for (int k = 0; k < 100_000; k++)
                s += k;
        System.out.println ("String complete.");
        
        
        System.out.println ("StringBuffer START");
        StringBuffer sb = new StringBuffer();
        for (int k = 0; k < 100_000; k++)
                sb.append ("" + k);
        System.out.println ("StringBuffer complete.");
        
    }
    
}
