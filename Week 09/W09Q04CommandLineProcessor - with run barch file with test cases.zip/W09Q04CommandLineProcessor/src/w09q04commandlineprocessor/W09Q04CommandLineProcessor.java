/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package w09q04commandlineprocessor;

/**
 *
 * @author omalleym
 */
public class W09Q04CommandLineProcessor {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here
        System.out.println ("Program running ...");
        
        if (args.length == 0) 
        {
            System.out.println ("Input is to be from the standard input");
        }
        else if ((args.length == 2) && (args[0].equals ("-f") == true) )
        {
            System.out.println ("Input is to be read from the file " + args[1]);
        }
        else
        {
            System.out.println ("Usage: program -f filename or program");
            System.exit(-1); // Error: signal to calling program that there was an error.
        }

        System.out.println ("Program completed.");
        System.out.println ("Have a Nice Day !");
    }
    
}
