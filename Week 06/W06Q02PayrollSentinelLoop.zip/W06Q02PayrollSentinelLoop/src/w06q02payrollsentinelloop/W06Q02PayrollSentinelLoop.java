/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w06q02payrollsentinelloop;

import java.util.Scanner;

/**
 *
 * @author omalleym
 */
public class W06Q02PayrollSentinelLoop 
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        int counter    = 0;
        double average = 0.0;
        double total   = 0.0;
        double amount  = 0.0;
        double maximum = 0.0;
        boolean keepLooping = true;
        Scanner kb = new Scanner (System.in);
        
        while (keepLooping == true)
        {
            System.out.print ("Enter Payroll amount (-1 to quit): ");
            //System.out.print ("Enter Payroll amount (-ve to quit): ");

            amount = kb.nextDouble();

            // WARNING: float and double are NOT stored exactly in computers.
            
            //if (amount == -1)                   // Danger !!!
            if (Math.abs(amount - -1) < 0.000001) // OK, safe. Amount is very close to -1
            //if (amount < 0)
            {
                keepLooping = false;
            }
            else
            {
                counter++;

                total += amount;
                
                if (maximum < amount)
                    maximum = amount;
            }
        }
        System.out.println ();
        
        if (counter == 0)
            System.out.println ("ERROR: no data has been entered.");
        else
        {
            average = total / counter;
            
            System.out.println ("Processing Summary:");
            System.out.println ("-> Number of Payrolls entered:  " + String.format ("%,7d",    counter) );
            System.out.println ("-> Maximum Payroll amount:     $" + String.format ("%,10.2f", maximum) );
            System.out.println ("-> Average Payroll amount:     $" + String.format ("%,10.2f", average) );
            System.out.println ("-> Total   Payroll amount:     $" + String.format ("%,10.2f", total  ) );
        }
    } // public static void main(String[] args) 

} // public class W06Q02PayrollSentinelLoop 
