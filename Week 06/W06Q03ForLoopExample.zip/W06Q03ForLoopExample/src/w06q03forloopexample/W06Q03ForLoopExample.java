/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w06q03forloopexample;

import java.util.Scanner;

/**
 *
 * @author omalleym
 */
public class W06Q03ForLoopExample {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        /*
        Pseudo Code:
            Get number of integers (count)
            Loop count times
                    Get the integer (int)
                    Do we have a new max ? (max < int)
                            Max = int
                    Sum = Sum + int
            Calculate Avg
            Display Max, Sum, Avg
        */
        /*
        int    count = 0;
        int    val   = 0;
        int    max   = 0;
        int    sum   = 0;
        double avg   = 0.0;
        
        Scanner kb = new Scanner (System.in);
        
        System.out.print ("Enter how many integers: ");
        count = kb.nextInt();
        
        for (int k = 0; k < count; k++)
        {
            System.out.print ("Enter integer #" + (k+1) + ": ");
            val = kb.nextInt();
            
            if (max < val)
                max = val;
            
            sum += val;
        }
        
        if (count > 0)
            avg = sum / count; // WARNING !
        
        System.out.println ("Max = " + max + ", Sum = " + sum + ", Avg = " + String.format ("%.2f", avg) );

*/
        // My Java Code from the Tutorial Word Doc
        // I wrote the Pseudo Code and then line by line - in Word doc - wrote the Java code next to the Pseudo Code
        
        int max = 0;
        int sum = 0;
        double avg = 0;
        Scanner kb = new Scanner(System.in);
        System.out.print ("Enter number of ints: ");
        int count = kb.nextInt();

        for (int k = 0;  k < count; k++)
        {
            System.out.print ("Enter int: ");
            int val = kb.nextInt();

           if (val > max)
                max = val;       

           sum = sum + val;
        }
        if (count > 0)
            avg = 1.0 * sum / count; 
           // OR:    avg = (double) sum / count; 


        System.out.println ("Maximum: " + max +
          ", Sum: " + sum + ", Average: " + 
           String.format ("%.2f", avg) );

    }
    
}
