/*
A mail-order house sells five products whose retail prices are as follows: 
product 1, $2.99; product 2, $4.50; product 3, $9.99; product 4, $4.49 and product 5, $7.00. 
(This should be familiar - you wrote the switch statement to find the price of a product in an earlier tutorial question.)

The application is to:
•	Use a sentinel-controlled loop to read a series of purchases as follows:
o	Product number (1 -5)
o	Quantity sold 
A product number of 0 is to be used as the sentinel value to terminate the loop.
•	Determine the retail price for each product purchased. 
•	Calculate and display the value of each purchase (given the retail price and quantity purchased)
•	On completion of data entry, display the total value of all purchases.

An example of the output for the final coded application would be:
Enter the product number (1-5)(or 0 to end): 1
Enter the quantity sold: 10
Sold 10 items of product id: 1 at $2.99 each. Cost = $29.90
Enter the product number (1-5). <O to terminate the program>: 2
Enter the quantity sold: 10
Sold 10 items of product id: 2 at $4.50 each. Cost = $45.00
Enter the product number (1-5). <O to terminate the program>: 3
Enter the quantity sold: 10
Sold 10 items of product id: 3 at $9.99 each. Cost = $99.90
Enter the product number (1-5). <O to terminate the program>: 4
Enter the quantity sold: 10
Sold 10 items of product id: 4 at $4.49 each. Cost = $44.90
Enter the product number (1-5). <O to terminate the program>: 5
Enter the quantity sold: 10
Sold 10 items of product id: 5 at $7.00 each. Cost = $70.00
Enter the product number (1-5). <O to terminate the program>: 0
The total value of the purchases = $289.70

 */
package w06q04mailorder;

import java.util.Scanner;

/**
 *
 * @author omalleym
 */
public class W06Q04MailOrder {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here
        
        /*
        Pseudo Code;
        
        LOOP while ProductNumber Not 0
            Prompt user for ProductNumber (0=exit)
            if ProductNumber > 0
                Prompt user for NumberSold
                Lookup the ProductPrice (switch from last week)
                    if ProductNumber = 1
                        ProductPrice = 2.99;
                    else if ProductNumber = 2
                        ProductPrice = 4.50;
                    // etc for others
        
                Cost = NumberSold * ProductPrice
                Dispay the NumberSold, ProductNum, ProductPrice, and Cost
                total = total + Cost
        
        Display total
        */

        int    productNumber = 0;
        int    numberSold    = 0;
        double productPrice  = 0.0;
        double cost          = 0.0;
        double total         = 0.0;

        Scanner kb = new Scanner (System.in);

        do
        {
            System.out.print ("Enter Product Number (0=exit): ");
            productNumber = kb.nextInt();

            // Lookup the Product Price:
            switch (productNumber)
            {
                case 1:  productPrice = 2.99;  break;
                case 2:  productPrice = 4.50;  break;
                case 3:  productPrice = 9.99;  break;
                case 4:  productPrice = 4.49;  break;
                case 5:  productPrice = 7.00;  break;
                default: productPrice = -1;
                         System.out.println("Invalid product number. Must be 1-5");
                         break;
            }
            
            if (productPrice > 0)
            {
                System.out.print ("Enter Number Sold: ");
                numberSold = kb.nextInt();
                
                if (numberSold > 0)
                {
                    cost = productPrice * numberSold;
                    total += cost;
                }

                System.out.println ("-> Product " + productNumber + ": sold " + numberSold + " @ $" + String.format ("%.2f", productPrice) + 
                                    " = $" + String.format ("%.2f", cost) );
            }
        } while (productNumber != 0);
        
        System.out.println ("Total Sales: $" + String.format ("%.2f", total) );

    }
}
