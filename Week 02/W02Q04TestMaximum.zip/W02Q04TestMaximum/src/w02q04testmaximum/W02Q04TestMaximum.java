/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w02q04testmaximum;

import java.util.Scanner;

/**
 *
 * @author omalleym
 */
public class W02Q04TestMaximum {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        /*
        // step 1: read and display the three values
        Create a Scanner to read in the data
        Prompt the user for the first value
        Read the first value (value1)
        Prompt the user for the second value
        Read the second value(value2)
        Prompt the user for the third value
        Read the third value (value3)
        display the three values
        */
        Scanner kb = new Scanner (System.in);
        System.out.print ("Enter integer #1: ");
        int n1 = kb.nextInt();
        System.out.print ("Enter integer #2: ");
        int n2 = kb.nextInt();
        System.out.print ("Enter integer #3: ");
        int n3 = kb.nextInt();

        // step 2: calculate and display the maximum – use the corrected code
        // Find the maximum of the three numbers using the corrected code from the previous question
        // display max
        int max = n1;
        
        if (n2 > max)
            max = n2;
        if (n3 > max)
            max = n3;

        System.out.println ("Max = " + max);
        
        // step 3: calculate and display the sum
        // sum = value1+value2+value3;
        // Display sum
        int sum = n1 + n2 + n3;
        System.out.println ("Sum = " + sum);

        // step 4: calculate and display the average
        // average = sum divided by 3
        // Display average
        double average = 1.0 * sum / 3;  // (double) sum / 3;
        System.out.println ("Average = " + String.format ("%.2f", average) ); // What is wrong ?????

        // step 5: calculate and display the product
        // product = value1 * value2 *value3
        // Display product
        int product = n1 * n2 * n3;
        System.out.println ("Product = " + product);

        
    }
    
}
