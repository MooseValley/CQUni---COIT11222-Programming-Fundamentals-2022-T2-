/*
Question 2 
You are to write an application that asks the user to enter one integer, obtains it from the user, and then 
displays the square of the number. It must then display whether the square of the number is greater than, 
equal to, or less than 100. 
An example of the output that would be displayed if the user entered the number 5 is shown below (the 5 on the 
first line is shown in bold and highlighted as it was input by the user):
Output
Enter an integer: 5
Number entered is: 5
The number squared is 25
5 squared is less than 100
 */
package w02q02integertester;

import java.util.Scanner;

/**
 * @author omalleym
 */
public class W02Q02IntegerTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here
        // Scanner ...
        Scanner kb = new Scanner (System.in);
        
        // Prompt the user for an integer
        System.out.print ("Enter an integer: ");
        
        // Get the integer
        int k = kb.nextInt();
        int squareK = k * k; // Or use:  Math.pow (k, 2);
        
        // Display number and the square
        System.out.println ("Number entered is: "     + k);
        System.out.println ("The number squared is: " + squareK);

        // Range check compae to 100
        if (squareK < 100)
            System.out.println (k + " squared is less than 100.");
        else if (squareK == 100)
            System.out.println (k + " squared is equal to 100.");
        else
            System.out.println (k + " squared is greater than 100.");
        
    }
    
}
