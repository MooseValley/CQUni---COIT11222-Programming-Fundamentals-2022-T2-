
package w02bq05programwitherrors;

//import java.util.Scanner; 
//import java.util.Date;
//import java.util.Random;
import java.util.*; 

import java.awt.Label;



public class Output {
 
        public static void main(String [] args) {
               int num ;
              Scanner input = new Scanner( System.in ); 
              num = input.nextInt(); 
        } 
    
}
